#ifndef SNAKE_H
#define SNAKE_H
#define SPEED (200 * 1000) // us
#define MAXLEN 400

typedef struct SNAKE {
    char direction; // 方向
    int len;
    int pos_x[MAXLEN];
    int pos_y[MAXLEN];
} Snake;

typedef struct FOOD {
    int pos_x;
    int pos_y;
} Food;

Snake *initSnake();
void Print(Snake *p, Food *food);
Food *creatFood(Snake *p);
void snakeMove(Snake *p);
int isEated(Snake *p, Food *food);
int isDeath(Snake *p);
void printScore(Snake *p);
void setNonBlocking(int fd);
#endif