#ifndef MAP_H
#define MAP_H

#define WIDTH 100
#define HIGHT 50

void createMap();


#endif