#include "map.h"
#include <stdio.h>
void createMap()
{
    for (int i = 1; i < WIDTH; i += 2) {
        // 打印上下边界
        printf("\033[%d;%df", 1, i); // 移动光标到指定位置
        printf("\033[33m■\033[0m");
        printf("\033[%d;%df", HIGHT, i);
        printf("\033[33m■\033[0m");
    }
    for (int i = 2; i <= HIGHT; i++) {
        // 打印左右边界
        printf("\033[%d;%df", i, 1);
        printf("\033[33m■\033[0m");
        printf("\033[%d;%df", i, WIDTH - 1);
        printf("\033[33m■\033[0m");
    }
}


