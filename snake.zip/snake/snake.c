#include "snake.h"
#include "map.h"
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>
Snake *initSnake()
{
    Snake *p_snake = (Snake *)malloc(sizeof(Snake));
    memset(p_snake, 0, sizeof(Snake));
    // 头
    p_snake->pos_x[0] = 49;
    p_snake->pos_y[0] = 25;

    p_snake->pos_x[1] = 49;
    p_snake->pos_y[1] = 26;

    p_snake->pos_x[2] = 49;
    p_snake->pos_y[2] = 27;

    p_snake->direction = 65; // 上
    p_snake->len = 3;
    return p_snake;
}

/*将食物和蛇身打印出来*/
void Print(Snake *p, Food *food)
{
    // 打印食物
    printf("\033[%d;%df", food->pos_y, food->pos_x);
    printf("\033[32m★\033[0m");
    // 打印蛇
    for (int i = 0; i < p->len; i++) {
        printf("\033[%d;%df", p->pos_y[i], p->pos_x[i]);
        if (i == 0) {
            printf("\033[36m●\033[0m");
        } else {
            printf("●");
        }
    }
}

Food *creatFood(Snake *p)
{
    Food *food = (Food *)malloc(sizeof(Food));
    srand(time(NULL));
    int flag = 0;
    do {
        food->pos_x = (rand() % (WIDTH / 2 - 1)) * 2 + 3;
        food->pos_y = rand() % (HIGHT - 2) + 2;
        for (int i = 0; i < p->len; i++) {
            if (food->pos_x == p->pos_x[i] && food->pos_y == p->pos_y[i]) {
                flag = 1;
            } else {
                flag = 0;
            }
        }
    } while (flag);
    return food;
}

void snakeMove(Snake *p)
{
    setNonBlocking(0);

    char key = getchar();
    key = getchar();
    key = getchar();
    switch (key) {
    case 65:
        if (p->direction != 66) {
            p->direction = 65;
        }
        break;
    case 66:
        if (p->direction != 65) {
            p->direction = 66;
        }
        break;
    case 68:
        if (p->direction != 67) {
            p->direction = 68;
        }
        break;
    case 67:
        if (p->direction != 68) {
            p->direction = 67;
        }
        break;
    default:
        break;
    }

    for (int i = p->len - 1; i > 0; i--) {
        p->pos_x[i] = p->pos_x[i - 1];
        p->pos_y[i] = p->pos_y[i - 1];
    }

    switch (p->direction) {
    case 65:
        p->pos_x[0] = p->pos_x[1];
        p->pos_y[0] = p->pos_y[1] - 1;
        break;
    case 66:
        p->pos_x[0] = p->pos_x[1];
        p->pos_y[0] = p->pos_y[1] + 1;
        break;
    case 68:
        p->pos_x[0] = p->pos_x[1] - 2;
        p->pos_y[0] = p->pos_y[1];
        break;
    case 67:
        p->pos_x[0] = p->pos_x[1] + 2;
        p->pos_y[0] = p->pos_y[1];
        break;
    default:
        break;
    }
}

int isEated(Snake *p, Food *food)
{
    if (p->pos_x[0] == food->pos_x && p->pos_y[0] == food->pos_y) {
        p->pos_x[p->len] = food->pos_x;
        p->pos_y[p->len] = food->pos_y;
        p->len += 1;
        return 1;
    }
    return 0;
}

int isDeath(Snake *p)
{
    if (p->pos_x[0] < 1 || p->pos_x[0] == WIDTH - 1) {
        return 1;
    }
    if (p->pos_y[0] <= 1 || p->pos_y[0] == HIGHT) {
        return 1;
    }
    for (int i = 1; i < p->len; i++) {
        if (p->pos_x[0] == p->pos_x[i] && p->pos_y[0] == p->pos_y[i]) {
            return 1;
        }
    }
    return 0;
}

void printScore(Snake *p)
{
    int tmp = 0;
    FILE *fp = fopen("score.txt", "r+");
    if (fp == NULL) {
        if ((fp = fopen("score.txt", "w")) == NULL) {
            perror("fopen error");
        }
        fwrite(&tmp, sizeof(int), 1, fp);
    }

    fread(&tmp, sizeof(int), 1, fp);
    fclose(fp);

    if (p->len - 3 > tmp) {
        if ((fp = fopen("score.txt", "w")) == NULL) {
            perror("fopen error");
            exit(-1);
        }
        tmp = p->len - 3;
        fwrite(&tmp, sizeof(int), 1, fp);
        printf("得分：%d           历史最高：%d\n", p->len - 3, p->len - 3);
        return;
    }
    printf("得分：%d           历史最高：%d\n", p->len - 3, tmp);
}

void setNonBlocking(int fd)
{
    struct termios ttystate;
    tcgetattr(fd, &ttystate);
    ttystate.c_lflag &= ~ICANON; // 关闭规范模式
    ttystate.c_cc[VMIN] = 0;     // 读取的最小字符数
    tcsetattr(fd, TCSANOW, &ttystate);
}