#include "map.h"
#include "snake.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
int main(int argc, char const *argv[])
{
    Snake *p_snake = initSnake();
    Food *food = creatFood(p_snake);

    system("stty -icanon"); // 设置一次性读完操作，不需要按enter
    system("stty -echo");   // 关闭回显

    while (1) {
        system("clear");
        createMap();
        printf("\033[%d;%df", HIGHT + 1, 0);
        printf("得分：%d\n", p_snake->len - 3);

        Print(p_snake, food);
        snakeMove(p_snake);
        if (isDeath(p_snake)) {
            break;
        }
        if (isEated(p_snake, food)) {
            food = creatFood(p_snake);
        }
        usleep(90000);
    }
    // system("stty icanon"); // 取消一次性读完操作
    // system("stty echo");   // 打开回显

    printf("\033[%d;%df", HIGHT + 1, 0);
    printScore(p_snake);
    return 0;
}
